const burger = document.querySelector('.burger');
const navLinks = document.querySelector('.nav-links');

burger.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Adiciona redirecionamento ao clicar no botão "Ler Mais"
document.querySelectorAll('.ler-mais').forEach(item => {
    item.addEventListener('click', event => {
        window.location.href = item.getAttribute('href');
    });
});